jar cvfe Reduce.jar mainfiles.Reduce mainfiles/Reduce.class automata/*.class datastructure/*.class comparator/*.class algorithms/*.class
