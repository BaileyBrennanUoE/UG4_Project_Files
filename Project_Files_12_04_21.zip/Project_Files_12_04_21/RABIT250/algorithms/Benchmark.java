package algorithms;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import automata.FAState;
import automata.FiniteAutomaton;
import datastructure.Pair;

public class Benchmark {
	
	private int la;
	//private int td;
	private static String testFolder;
	private int testSize;
	private List<String[]> dataLines = new ArrayList<>();
	private static int cores;
    
    
	private Set<Pair<FAState,FAState>> serialResult = null;
	private Set<Pair<FAState,FAState>> parResult = null;
	private Set<Pair<FAState,FAState>> expResult = null;
	
	private long[] serialRunTimes;
	private long[] parRunTimes;
	private long[] expRunTimes;
	
	private static String mode;
	
	Benchmark(int la, int testSize) {
		this.la = la;
		this.testSize = testSize;
		this.serialRunTimes = new long[testSize/2];
		this.parRunTimes = new long[testSize/2];
		this.expRunTimes = new long[testSize/2];
	}
	
	public static void main(String[] args) {
		
		mode = args[3];
		int system_cores = Runtime.getRuntime().availableProcessors();
		if(args.length==4) {
			cores = system_cores;
		} else {
			cores = Integer.parseInt(args[4]);
			if(cores > system_cores)
				cores = system_cores;
		}
		
		testFolder=args[1];
		
		Benchmark benchmark = new Benchmark(
				Integer.parseInt(args[0]), 
				Integer.parseInt(args[2])
				);
		
		benchmark.printSystemResources();
		benchmark.warmUp();
		
		switch(mode) {
		case "serial":
			benchmark.runSerialTest();
			break;
		case "par":
			benchmark.runParTest();
			break;
		case "exp":
			benchmark.runExpTest();
			break;
		case "compare":
			benchmark.runCompareTest();
			break;
		case "exp-compare":
			benchmark.runExpCompareTest();
			break;
		case "jumping-compare":
			benchmark.runJumpingCompareTest();
			break;
		case "jumping-par":
			benchmark.runJumpingTest();
			break;
		case "jumping-serial":
			benchmark.runJumpingSerialTest();
			break;
		}
		
		try {
			benchmark.writeToCSV();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
    }
	
	/*
	 * modified code from: 
	 * 	https://stackoverflow.com/questions/23636326/detect-system-specs-with-java
	 */
	
	public void printSystemResources() {
		
		long kilobytes = 1024;
	    long megabytes = kilobytes * 1024;
		
	    String nameOS = "os.name";  
	    String versionOS = "os.version";  
	    String architectureOS = "os.arch";
	    System.out.println(
	    		"\t-------------------------------------------------"
	    		);
	    System.out.println(
	    		"\t|Info about PC\t\t\t\t\t|"
	    		);
	    System.out.println(
	    		"\t-------------------------------------------------"
	    		);
	    System.out.println("\t|OS Name:\t\t\t" + 
	    System.getProperty(nameOS)+"\t|");
	    System.out.println("\t|OS Version:\t\t\t" + 
	    System.getProperty(versionOS)+"\t\t|");
	    System.out.println("\t|OS Architecture:\t\t" + 
	    System.getProperty(architectureOS)+"\t\t|");
	    
		/* Total number of processors or cores available to the JVM */
	    System.out.println("\t|Available processors (cores):\t" + 
	        Runtime.getRuntime().availableProcessors()+"\t\t|");
	    System.out.println("\t|Used processors (cores):\t" + 
	    	cores+"\t\t|");

	    /* This will return Long.MAX_VALUE if there is no preset limit */
	    long maxMemory = Runtime.getRuntime().maxMemory();
	    /* Maximum amount of memory the JVM will attempt to use */
	    System.out.println("\t|Maximum memory (megabytes):\t" + 
	        (maxMemory == Long.MAX_VALUE ? "no limit" 
	        : maxMemory / (float) megabytes)+"\t\t|");
	    System.out.println(
	    		"\t-------------------------------------------------"
	    		);
	}
	
	private void warmUp() {
		
		System.out.println(
        		"\tWarming up..."
        		);
		
		for(int n=0; n<50; n=n+2) {
			
			FiniteAutomaton omega1 = 
					new FiniteAutomaton(
							"warmup"+
							File.separator+"testFile"+n+".ba"
							);
	        omega1.name = "warmup"+
	        				File.separator+"testFile"+n+".ba";
	        FiniteAutomaton omega2 =  
	        		new FiniteAutomaton(
	        			"warmup"+
	        			File.separator+"testFile"+(n+1)+".ba"
	        		);
	        omega2.name = "warmup"+
	        			File.separator+"testFile"+(n+1)+".ba";
	        
	        BLAFairSimRelNBWPar par = new BLAFairSimRelNBWPar(cores);
	        par.BLAFairSimRelNBW(omega1, omega2, la);
		}
        
        System.out.println(
        		"\tWarm up finished"
        		);

	}
	
	private void runCompareTest() {
		long startSim;
		boolean testResult = true;
		int runNo = 0;
		for(int n=0; n<testSize; n=n+2) {
			runNo = (int) Math.floor(n/2);
			FiniteAutomaton omega1 = 
					new FiniteAutomaton(
							testFolder+
							File.separator+"testFile"+n+".ba"
							);
	        omega1.name = testFolder+
	        		File.separator+"testFile"+n+".ba";
	        FiniteAutomaton omega2 = 
	        		new FiniteAutomaton(
	        				testFolder+
	        			File.separator+"testFile"+(n+1)+".ba"
	        		);
	        omega2.name = testFolder+
	        			File.separator+"testFile"+(n+1)+".ba";
	        
	        Simulation serial = new Simulation();
	        startSim = System.currentTimeMillis();
	        serialResult = serial.BLAFairSimRelNBW(omega1, omega2, la);
	        serialRunTimes[runNo] = (System.currentTimeMillis() - startSim);
	       
	        BLAFairSimRelNBWPar par = new BLAFairSimRelNBWPar(cores);
	        startSim = System.currentTimeMillis();
	        parResult = par.BLAFairSimRelNBW(omega1, omega2, la);
	        parRunTimes[runNo] = (System.currentTimeMillis() - startSim);
	        
	        testResult=testResult && serialResult.containsAll(parResult);

	        System.out.println(
	        		"\tRun "+runNo+
	        		"\tPar Pass: "+serialResult.containsAll(parResult)+
	        		"\tSerial: "+serialRunTimes[runNo]+"ms"+
	        		"\tPar: "+parRunTimes[runNo]+"ms"
	        		);
	        
	        dataLines.add(new String[] 
	        		{ "Serial", 
	        		String.valueOf(runNo),
	        		String.valueOf(serialRunTimes[runNo])
	        		});
	        dataLines.add(new String[]
	        		{ "Parallel", 
	        		String.valueOf(runNo),
	        		String.valueOf(parRunTimes[runNo]),
	        		String.valueOf(serialResult.containsAll(parResult))
	        		});
		}
		int sumSerial=0;
		int sumPar=0;
		for(int n=0; n<(testSize/2); n++) {
			sumSerial += serialRunTimes[n];
			sumPar += parRunTimes[n];
		}
		
		
		System.out.println("\tAll runs passed: "+testResult);
		System.out.println(
				"\tTotal Ser Runtime: "+sumSerial+"ms"+
				"\tAvg Ser time: "+(sumSerial/(testSize/2))+"ms"+
				"\tStandard Deviation: "+
					getStndrDev(serialRunTimes, (sumSerial/(testSize/2)))+"ms"+
				"\tMedian Runtime: "+getMedian(serialRunTimes)+"ms"
				);
		System.out.println(
				"\tTotal Par Runtime: "+sumPar+"ms"+
				"\tAvg Par time: "+(sumPar/(testSize/2))+"ms"+
				"\tStandard Deviation: "+
					getStndrDev(parRunTimes, (sumPar/(testSize/2)))+"ms"+
				"\tMedian Runtime: "+getMedian(parRunTimes)+"ms"
				);
		System.out.println(
				"\tBiggest time difference with Serial sim taking "+
				getBiggestDiff(serialRunTimes, parRunTimes)+"ms"+
				" longer than Parallel sim"
				);
		System.out.println(
				"\tParallel was faster than Serial "+
				howManyFaster(serialRunTimes, parRunTimes)+" times"
				);
	}
	
	private void runExpCompareTest() {
		long startSim;
		boolean testResult = true;
		int runNo = 0;
		int failCounter = 0;
		for(int n=0; n<testSize; n=n+2) {
			runNo = (int) Math.floor(n/2);
			FiniteAutomaton omega1 = 
					new FiniteAutomaton(
							testFolder+
							File.separator+"testFile"+n+".ba"
							);
	        omega1.name = testFolder+
	        		File.separator+"testFile"+n+".ba";
	        FiniteAutomaton omega2 = 
	        		new FiniteAutomaton(
	        				testFolder+
	        			File.separator+"testFile"+(n+1)+".ba"
	        		);
	        omega2.name = testFolder+
	        			File.separator+"testFile"+(n+1)+".ba";
	        
	        BLAFairSimRelNBWPar par = new BLAFairSimRelNBWPar(cores);
	        startSim = System.currentTimeMillis();
	        parResult = par.BLAFairSimRelNBW(omega1, omega2, la);
	        long parTime = (System.currentTimeMillis() - startSim);
	        
	        BLAFairSImRelNBWExp exp = new BLAFairSImRelNBWExp(cores);
	        startSim = System.currentTimeMillis();
	        expResult = exp.BLAFairSimRelNBW(omega1, omega2, la);
	        long expTime = (System.currentTimeMillis() - startSim);
	       
	        if(!parResult.containsAll(expResult)) {
	        	failCounter++;
	        	System.out.println(
		        		"\tRun "+runNo+
		        		"\tFAILED"
		        		);
	        	continue;
	        }
	        
        	parRunTimes[runNo] = parTime;
        	expRunTimes[runNo] = expTime;
	        
        	testResult=testResult && parResult.containsAll(expResult);
        	
	        System.out.println(
	        		"\tRun "+runNo+
	        		"\tExp Pass: "+parResult.containsAll(expResult)+
	        		"\tPar: "+parRunTimes[runNo]+"ms"+
	        		"\tExp: "+expRunTimes[runNo]+"ms"
	        		);
	        
	        dataLines.add(new String[]
	        		{ "Parallel", 
	        		String.valueOf(runNo),
	        		String.valueOf(parRunTimes[runNo])
	        		});
	        dataLines.add(new String[] 
	        		{ "Experimental", 
	        		String.valueOf(runNo),
	        		String.valueOf(expRunTimes[runNo]),
	        		String.valueOf(parResult.containsAll(expResult))
	        		});
		}
		int sumPar=0;
		int sumExp=0;
		for(int n=0; n<((testSize/2)-failCounter); n++) {
			sumPar += parRunTimes[n];
			sumExp += expRunTimes[n];
		}
		
		System.out.println("\tAll runs passed: "+testResult);
		System.out.println(
				"\tTotal Par Runtime: "+sumPar+"ms"+
				"\tAvg Par time: "+(sumPar/(testSize/2))+"ms"+
				"\tStandard Deviation: "+
					getStndrDev(parRunTimes, (sumPar/((testSize/2)-failCounter)))+"ms"+
				"\tMedian Runtime: "+getMedian(parRunTimes)+"ms"
				);
		System.out.println(
				"\tTotal Exp Runtime: "+sumExp+"ms"+
				"\tAvg Exp time: "+(sumExp/(testSize/2))+"ms"+
				"\tStandard Deviation: "+
					getStndrDev(expRunTimes, (sumExp/((testSize/2)-failCounter)))+"ms"+
				"\tMedian Runtime: "+getMedian(expRunTimes)+"ms"
				);
		System.out.println(
				"\tFail rate of Experimental: "+
				failCounter + "/" +(testSize/2)
				);
	}
	
	private void runSerialTest() {
		long startSim;
		int runNo = 0;
		for(int n=0; n<testSize; n=n+2) {
			runNo = (int) Math.floor(n/2);
			FiniteAutomaton omega1 = 
					new FiniteAutomaton(
							testFolder+
							File.separator+"testFile"+n+".ba"
							);
	        omega1.name = testFolder+
	        			File.separator+"testFile"+n+".ba";
	        FiniteAutomaton omega2 = 
	        		new FiniteAutomaton(
	        				testFolder+
	        			File.separator+"testFile"+(n+1)+".ba"
	        		);
	        omega2.name = testFolder+
	        			File.separator+"testFile"+(n+1)+".ba";
	       
	        Simulation serial = new Simulation();
	        startSim = System.currentTimeMillis();
	        serial.BLAFairSimRelNBW(omega1, omega2, la);
	        serialRunTimes[runNo] = (System.currentTimeMillis() - startSim);
	        
	        System.out.println(
	        		"\tRun "+runNo+
	        		"\tPar: "+serialRunTimes[runNo]+"ms"
	        		);
	        
	        dataLines.add(new String[]
	        		{ "Parallel", 
	        		String.valueOf(runNo),
	        		String.valueOf(serialRunTimes[runNo]),
	        		});
		}
		int sumSerial=0;
		for(int n=0; n<(testSize/2); n++) {
			sumSerial += serialRunTimes[n];
		}
		
		System.out.println(
				"\tTotal Par Runtime: "+sumSerial+"ms"+
				"\tAvg Par time: "+(sumSerial/(testSize/2))+"ms"+
				"\tStandard Deviation: "+
					getStndrDev(serialRunTimes, (sumSerial/(testSize/2)))+"ms"+
				"\tMedian Runtime: "+getMedian(serialRunTimes)+"ms"
				);
	}
	
	private void runParTest() {
		long startSim;
		int runNo = 0;
		for(int n=0; n<testSize; n=n+2) {
			runNo = (int) Math.floor(n/2);
			FiniteAutomaton omega1 = 
					new FiniteAutomaton(
							testFolder+
							File.separator+"testFile"+n+".ba"
							);
	        omega1.name = testFolder+
	        		File.separator+"testFile"+n+".ba";
	        FiniteAutomaton omega2 = 
	        		new FiniteAutomaton(
	        				testFolder+
	        			File.separator+"testFile"+(n+1)+".ba"
	        		);
	        omega2.name = testFolder+
	        			File.separator+"testFile"+(n+1)+".ba";
	       
	        BLAFairSimRelNBWPar par = new BLAFairSimRelNBWPar(cores);
	        startSim = System.currentTimeMillis();
	        parResult = par.BLAFairSimRelNBW(omega1, omega2, la);
	        parRunTimes[runNo] = (System.currentTimeMillis() - startSim);
	        
	        System.out.println(
	        		"\tRun "+runNo+
	        		"\tPar: "+parRunTimes[runNo]+"ms" 
	        		);
	        
	        dataLines.add(new String[]
	        		{ "Parallel", 
	        		String.valueOf(runNo),
	        		String.valueOf(parRunTimes[runNo]),
	        		});
		}
		int sumPar=0;
		for(int n=0; n<(testSize/2); n++) {
			sumPar += parRunTimes[n];
		}
		
		System.out.println(
				"\tTotal Par Runtime: "+sumPar+"ms"+
				"\tAvg Par time: "+(sumPar/(testSize/2))+"ms"+
				"\tStandard Deviation: "+
					getStndrDev(parRunTimes, (sumPar/(testSize/2)))+"ms"+
				"\tMedian Runtime: "+getMedian(parRunTimes)+"ms"
				);
	}
	
	private void runExpTest() {
		long startSim;
		int runNo = 0;
		for(int n=0; n<testSize; n=n+2) {
			runNo = (int) Math.floor(n/2);
			FiniteAutomaton omega1 = 
					new FiniteAutomaton(
							testFolder+
							File.separator+"testFile"+n+".ba"
							);
	        omega1.name = testFolder+
	        			File.separator+"testFile"+n+".ba";
	        FiniteAutomaton omega2 = 
	        		new FiniteAutomaton(
	        				testFolder+
	        			File.separator+"testFile"+(n+1)+".ba"
	        		);
	        omega2.name = testFolder+
	        		File.separator+"testFile"+(n+1)+".ba";
	       
	        BLAFairSImRelNBWExp exp = new BLAFairSImRelNBWExp(cores);
	        startSim = System.currentTimeMillis();
	        exp.BLAFairSimRelNBW(omega1, omega2, la);
	        expRunTimes[runNo] = (System.currentTimeMillis() - startSim);
	        
	        System.out.println(
	        		"\tRun "+runNo+
	        		"\tExp: "+expRunTimes[runNo]+"ms"
	        		);
	        
	        dataLines.add(new String[]
	        		{ "Experimental", 
	        		String.valueOf(runNo),
	        		String.valueOf(expRunTimes[runNo]),
	        		});
		}
		int sumExp=0;
		for(int n=0; n<(testSize/2); n++) {
			sumExp += expRunTimes[n];
		}
		
		System.out.println(
				"\tTotal Exp Runtime: "+sumExp+"ms"+
				"\tAvg Exp time: "+(sumExp/(testSize/2))+"ms"+
				"\tStandard Deviation: "+
					getStndrDev(parRunTimes, (sumExp/(testSize/2)))+"ms"+
				"\tMedian Runtime: "+getMedian(expRunTimes)+"ms"
				);
	}
	
	private void runJumpingCompareTest() {
		long startSim;
		boolean testResult = true;
		int runNo = 0;
		boolean serialJumpingResult;
		boolean parJumpingResult;
		for(int n=0; n<testSize; n=n+2) {
			runNo = (int) Math.floor(n/2);
			FiniteAutomaton omega1 = 
					new FiniteAutomaton(
							testFolder+
							File.separator+"testFile"+n+".ba"
							);
	        omega1.name = testFolder+
	        			File.separator+"testFile"+n+".ba";
	        FiniteAutomaton omega2 = 
	        		new FiniteAutomaton(
	        				testFolder+
	        			File.separator+"testFile"+(n+1)+".ba"
	        		);
	        omega2.name = testFolder+
	        		File.separator+"testFile"+(n+1)+".ba";
	        
	        Simulation serial = new Simulation();
	        startSim = System.currentTimeMillis();
	        serialJumpingResult = serial.JumpingBLAFairSimRelNBW(omega1, omega2, la, 1);
	        serialRunTimes[runNo] = (System.currentTimeMillis() - startSim);
	        //serialTime += (System.currentTimeMillis() - startSim);
	       
	        JumpingBLAFairSimRelNBWPar par = new JumpingBLAFairSimRelNBWPar(cores);
	        startSim = System.currentTimeMillis();
	        parJumpingResult = par.JumpingBLAFairSimRelNBW(omega1, omega2, la, 1);
	        parRunTimes[runNo] = (System.currentTimeMillis() - startSim);
	        
	        testResult=testResult && (serialJumpingResult==parJumpingResult);
	        
	        System.out.println(
	        		"\tRun "+runNo+
	        		"\tPar Pass: "+(serialJumpingResult==parJumpingResult)+
	        		"\tSerial: "+serialRunTimes[runNo]+"ms"+
	        		"\tPar: "+parRunTimes[runNo]+"ms"
	        		);
	        
	        dataLines.add(new String[] 
	        		{ "Serial", 
	        		String.valueOf(runNo),
	        		String.valueOf(serialRunTimes[runNo])
	        		});
	        dataLines.add(new String[]
	        		{ "Parallel", 
	        		String.valueOf(runNo),
	        		String.valueOf(parRunTimes[runNo]),
	        		String.valueOf(serialJumpingResult==parJumpingResult)
	        		});
		}
		int sumSerial=0;
		int sumPar=0;
		for(int n=0; n<(testSize/2); n++) {
			sumSerial += serialRunTimes[n];
			sumPar += parRunTimes[n];
		}
		
		
		System.out.println("\tAll runs passed: "+testResult);
		System.out.println(
				"\tTotal Ser Runtime: "+sumSerial+"ms"+
				"\tAvg Ser time: "+(sumSerial/(testSize/2))+"ms"+
				"\tStandard Deviation: "+
					getStndrDev(serialRunTimes, (sumSerial/(testSize/2)))+"ms"+
				"\tMedian Runtime: "+getMedian(serialRunTimes)+"ms"
				);
		System.out.println(
				"\tTotal Par Runtime: "+sumPar+"ms"+
				"\tAvg Par time: "+(sumPar/(testSize/2))+"ms"+
				"\tStandard Deviation: "+
					getStndrDev(parRunTimes, (sumPar/(testSize/2)))+"ms"+
				"\tMedian Runtime: "+getMedian(parRunTimes)+"ms"
				);
		System.out.println(
				"\tBiggest time difference with Serial sim taking "+
				getBiggestDiff(serialRunTimes, parRunTimes)+"ms"+
				" longer than Parallel sim"
				);
		System.out.println(
				"\tParallel was faster than Serial "+
				howManyFaster(serialRunTimes, parRunTimes)+" times"
				);
	}
	
	private void runJumpingTest() {
		long startSim;
		int runNo = 0;
		for(int n=0; n<testSize; n=n+2) {
			runNo = (int) Math.floor(n/2);
			FiniteAutomaton omega1 = 
					new FiniteAutomaton(
							testFolder+
							File.separator+"testFile"+n+".ba"
							);
	        omega1.name = testFolder+
	        			File.separator+"testFile"+n+".ba";
	        FiniteAutomaton omega2 = 
	        		new FiniteAutomaton(
	        				testFolder+
	        				File.separator+"testFile"+(n+1)+".ba"
	        		);
	        omega2.name = testFolder+
	        			File.separator+"testFile"+(n+1)+".ba";
	        
	        JumpingBLAFairSimRelNBWPar par = new JumpingBLAFairSimRelNBWPar(cores);
	        startSim = System.currentTimeMillis();
	        par.JumpingBLAFairSimRelNBW(omega1, omega2, la, 1);
	        parRunTimes[runNo] = (System.currentTimeMillis() - startSim);
	        
	        
	        System.out.println(
	        		"\tRun "+runNo+
	        		"\tPar: "+parRunTimes[runNo]+"ms"
	        		);
	        
	        dataLines.add(new String[]
	        		{ "Parallel", 
	        		String.valueOf(runNo),
	        		String.valueOf(parRunTimes[runNo])
	        		});
		}
		int sumPar=0;
		for(int n=0; n<(testSize/2); n++) {
			sumPar += parRunTimes[n];
		}
		
		System.out.println(
				"\tTotal Par Jumping Runtime: "+sumPar+"ms"+
				"\tAvg Par Jumping time: "+(sumPar/(testSize/2))+"ms"+
				"\tStandard Deviation: "+
					getStndrDev(parRunTimes, (sumPar/(testSize/2)))+"ms"+
				"\tMedian Runtime: "+getMedian(parRunTimes)+"ms"
				);
	}
	
	private void runJumpingSerialTest() {
		long startSim;
		int runNo = 0;
		for(int n=0; n<testSize; n=n+2) {
			runNo = (int) Math.floor(n/2);
			FiniteAutomaton omega1 = 
					new FiniteAutomaton(
							testFolder+
							File.separator+"testFile"+n+".ba"
							);
	        omega1.name = testFolder+
	        		File.separator+"testFile"+n+".ba";
	        FiniteAutomaton omega2 = 
	        		new FiniteAutomaton(
	        				testFolder+
	        			File.separator+"testFile"+(n+1)+".ba"
	        		);
	        omega2.name = testFolder+
	        			File.separator+"testFile"+(n+1)+".ba";
	        
	        Simulation serial = new Simulation();
	        startSim = System.currentTimeMillis();
	        serial.JumpingBLAFairSimRelNBW(omega1, omega2, la, 1);
	        serialRunTimes[runNo] = (System.currentTimeMillis() - startSim);
	        
	        
	        System.out.println(
	        		"\tRun "+runNo+
	        		"\tSerial: "+serialRunTimes[runNo]+"ms"
	        		);
	        
	        dataLines.add(new String[]
	        		{ "Parallel", 
	        		String.valueOf(runNo),
	        		String.valueOf(serialRunTimes[runNo])
	        		});
		}
		int sumSerial=0;
		for(int n=0; n<(testSize/2); n++) {
			sumSerial += serialRunTimes[n];
		}
		
		System.out.println(
				"\tTotal Par Jumping Runtime: "+sumSerial+"ms"+
				"\tAvg Par Jumping time: "+(sumSerial/(testSize/2))+"ms"+
				"\tStandard Deviation: "+
					getStndrDev(serialRunTimes, (sumSerial/(testSize/2)))+"ms"+
				"\tMedian Runtime: "+getMedian(serialRunTimes)+"ms"
				);
	}
	
	private int getStndrDev(long[] timeSet, int mean) {
		int sum=0;
		for(int n=0; n<timeSet.length; n++) {
			sum += (timeSet[n] - mean)*(timeSet[n] - mean);
		}
		double stndrDev = Math.sqrt(sum/(timeSet.length-1));
		return (int) Math.round(stndrDev);
	}
	
	private long getMedian(long[] timeSet) {
		Arrays.sort(timeSet);
		return timeSet[(timeSet.length/2)];
	}
	
	private int getBiggestDiff(long[] serialTimes, long[] parTimes){
		int diff=0;
		int max=0;
		for(int n=0; n<(testSize/2); n++)
			diff = (int) (serialTimes[n] - parTimes[n]);
			if(diff > max)
				max = diff;
		return max;
	}
	
	private int howManyFaster(long[] serialTimes, long[] parTimes){
		int count=0;
		for(int n=0; n<(testSize/2); n++) {
			if(parTimes[n] < serialTimes[n]) {
				count++;
			}	
		}
		return count;
	}
	
	/*
	 * modified code from: 
	 * 	https://www.baeldung.com/java-csv
	 */
	
	public String convertToCSV(String[] data) {
	    return Stream.of(data)
	      .map(this::escapeSpecialCharacters)
	      .collect(Collectors.joining(","));
	}
	
	public String escapeSpecialCharacters(String data) {
	    String escapedData = data.replaceAll("\\R", " ");
	    if (data.contains(",") || data.contains("\"") || data.contains("'")) {
	        data = data.replace("\"", "\"\"");
	        escapedData = "\"" + data + "\"";
	    }
	    return escapedData;
	}
	
	public void writeToCSV() throws IOException {
	    File csvOutputFile = new File("Benchmark_"+mode+"_Cores_"+cores+"_LA_"+la+"_TestSize_"+testSize+".csv");
	    try (PrintWriter pw = new PrintWriter(csvOutputFile)) {
	        dataLines.stream()
	          .map(this::convertToCSV)
	          .forEach(pw::println);
	    }
	}
}
