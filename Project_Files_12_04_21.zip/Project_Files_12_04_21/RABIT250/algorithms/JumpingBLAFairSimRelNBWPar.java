package algorithms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

import algorithms.ParallelSimulation.acc_PrerefThread;
import algorithms.ParallelSimulation.par_BLAB_refine;
import automata.FAState;
import automata.FiniteAutomaton;
import comparator.StatePairComparator;
import datastructure.HashSet;
import datastructure.Pair;

public class JumpingBLAFairSimRelNBWPar {
	
	private int num_proc;
    private ForkJoinPool forkJoinPool;
	
	private int threshold_forkjoin_la(int n_states){
        return Math.max(10,n_states/64);
    }
	
	JumpingBLAFairSimRelNBWPar(int cores){
		this.num_proc = cores;
	    this.forkJoinPool = new ForkJoinPool(num_proc);
	}
	
	/**
	 * Compute jumping BLA fair forward simulation relation between the initial states of two Buchi automata
	 * @param omega1, omega2: two Buchi automata
	 * @param la: integer >=1, the lookahead
	 * @param bwchoice: 0=no jumping, 1=jumping w.r.t. bla bw sim, 2=jumping w.r.t. bla counting bw sim, 3=jumping w.r.t. bla segmented bw sim, 
	 * @param 4=transitive closure of bla fair sim without jumping (this should subsume 1, but is slower to compute).
	 *
	 * @return true iff the initial state of omega2 can simulate the initial state of omega1. (For other states it does not mean much).
	 * Advice: Use this only after omega1/omega2 have been minimized with other techniques. Otherwise the high branching degree 
	 * of jumps makes higher lookaheads difficult to compute.
	 */

	     public boolean JumpingBLAFairSimRelNBW(FiniteAutomaton omega1, FiniteAutomaton omega2, int la, int bwchoice) 
	{
		ArrayList<FAState> all_states1=new ArrayList<FAState>();
		ArrayList<FAState> all_states2=new ArrayList<FAState>();
		HashSet<String> alphabet=new HashSet<String>();

		all_states1.addAll(omega1.states);
		alphabet.addAll(omega1.alphabet);
		all_states2.addAll(omega2.states);
		alphabet.addAll(omega2.alphabet);

		int n1 = all_states1.size();
		int n2 = all_states2.size();
		int n_symbols = alphabet.size();
		FAState[] states1 = all_states1.toArray(new FAState[0]);
		FAState[] states2 = all_states2.toArray(new FAState[0]);

		ArrayList<String> symbols=new ArrayList<String>(alphabet);

		boolean[] isFinal1 = new boolean[n1];
		boolean[] isFinal2 = new boolean[n2];
		// These give the numbers of the initial states. Only one for each automaton.
		int initial1=0;
		int initial2=0;
		for(int i=0; i<n1; i++){			
			isFinal1[i] = states1[i].getowner().F.contains(states1[i]);
			if(omega1.getInitialState().compareTo(states1[i])==0) initial1=i;
		}
		for(int i=0; i<n2; i++){			
			isFinal2[i] = states2[i].getowner().F.contains(states2[i]);
			if(omega2.getInitialState().compareTo(states2[i])==0) initial2=i;
		}

		int[][][] post1 = new int[n_symbols][n1][];
		int[][] post_len1 = new int[n_symbols][n1];
		int[][][] post2 = new int[n_symbols][n2][];
		int[][] post_len2 = new int[n_symbols][n2];

		    // Initialize memory of post
		for(int s=0;s<n_symbols;s++)
		{
			String a = symbols.get(s);
			    for(int p=0; p<n1; p++){
				Set<FAState> next = states1[p].getNext(a);
				post_len1[s][p]=0;
				if (next != null) post1[s][p] = new int[states1[p].getNext(a).size()];
			    }
			    for(int p=0; p<n2; p++){
				Set<FAState> next = states2[p].getNext(a);
				post_len2[s][p]=0;
				if (next != null) post2[s][p] = new int[states2[p].getNext(a).size()];
			    }
		}
		// Initialize post
		for(int s=0;s<n_symbols;s++)
		{
			String a = symbols.get(s);
			    for(int p=0; p<n1; p++){
				Set<FAState> next = states1[p].getNext(a);
				if (next != null){
				for(int q=0; q<n1; q++)		
				{
					if(next.contains(states1[q])) post1[s][p][post_len1[s][p]++] = q;
				}
				}
			    }
			    for(int p=0; p<n2; p++){
				Set<FAState> next = states2[p].getNext(a);
				if (next != null){
				for(int q=0; q<n2; q++)		
				{
					if(next.contains(states2[q])) post2[s][p][post_len2[s][p]++] = q;
				}
				}
			    }
		}

		int[][] jump = new int[n2][n2];
		int[] jump_len = new int[n2];
		int[][] acc_jump = new int[n2][n2];
		int[] acc_jump_len = new int[n2];

		boolean[][] W = new boolean[n1][n2];
		boolean[][] avoid = new boolean[n1][n2];

		// Compute BLA backward sim on omega2 for later jumps, depending on bwchoice parameter.
		{
		boolean[][] jumpmatrix = new boolean[n2][n2];
		if(bwchoice==1){
		    Set<Pair<FAState,FAState>> jumpsim;
		    jumpsim = BLABSimRelNBW(omega2, null, la);
		    for(int p=0; p<n2; p++)
			for(int q=0; q<n2; q++)
			    jumpmatrix[p][q]=jumpsim.contains(new Pair<FAState,FAState>(states2[p], states2[q]));
		}
		else{
		    System.out.println("Wrong bwchoice parameter specified, must be 1.");
		    return false;
		}
		
		get_jump(jump, jump_len, acc_jump, acc_jump_len, jumpmatrix, isFinal2, n2);
		}

		// Initialize W as false for the main loop. This will grow (more states winning for spoiler) until fixpoint reached
		// Exception: where spoiler can do an action that duplicator cannot do (even with jumping), then make it winning for spoiler.
		for(int p=0; p<n1; p++)
		    for(int q=0; q<n2; q++){
			W[p][q]=false;			
			for(int s=0;s<n_symbols;s++)
			    if(post_len1[s][p]>0 && !can_jumping_do(s,q,jump,jump_len,acc_jump,acc_jump_len,post_len2)) { W[p][q]=true; }
		    }

		
		boolean changed=true;
		while(changed){
		    // System.out.println("Computing JumpingBLAFair getavoid.");
		    changed=false;
		    JumpingBLAFair_getavoid(isFinal1,isFinal2,n1,n2,n_symbols,post1,post_len1,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,avoid,la);
		    // Copy avoid to W
		    for(int p=0; p<n1; p++)
			for(int q=0; q<n2; q++)
			    if(avoid[p][q] && !W[p][q]) { W[p][q]=true; changed=true; }
		    // Add pairs where spoiler can force the game into W
		    // System.out.println("Refining JumpingBLAFair.");
		    if(JumpingBLAFairPar_refine_W(n1,n2,n_symbols,post1,post_len1,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,la)) changed=true;
		    // If spoiler is winning then return false
		    if(W[initial1][initial2]) return false;
		}

		return true;
	}


    private boolean can_jumping_do(int s, int q, int[][] jump, int[] jump_len, int[][] acc_jump, int[] acc_jump_len, int[][] post_len2){
		for(int r=0; r<jump_len[q]; r++)
		    if(post_len2[s][jump[q][r]] >0) return true;
		for(int r=0; r<acc_jump_len[q]; r++)
		    if(post_len2[s][acc_jump[q][r]] >0) return true;
	        return false;
	}


    private boolean JumpingBLAFairPar_refine_W(int n1, int n2, int n_symbols, int[][][] post1, int[][] post_len1, int[][][] post2, int[][] post_len2, int[][] jump, int[] jump_len, int[][] acc_jump, int[] acc_jump_len, boolean[][] W, int la)
    {
    	return (forkJoinPool.invoke(new jumping_par_refine_W(0,n1,0,n2,n_symbols,post1,post_len1,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,la))>0);
    }
	
    class jumping_par_refine_W extends RecursiveTask<Integer> {
		int p1,p2,q1,q2;
		boolean[][] avoid;
		boolean[] isFinal;
		int n_states;
		int n_symbols;
		int[][][] post1;
		int[][] post_len1;
		int[][][] post2;
		int[][] post_len2;
		int[][] jump;
		int[] jump_len;
		int[][] acc_jump;
		int[] acc_jump_len;
		int[][][] post;
		int[][] post_len; 
		boolean[][] W;
		int la;
		
		jumping_par_refine_W(int p1, int p2, int q1, int q2, int n_symbols, int[][][] post1, int[][] post_len1, int[][][] post2, int[][] post_len2, int[][] jump, int[] jump_len, int[][] acc_jump, int[] acc_jump_len, boolean[][] W, int la){
		    this.p1=p1;
		    this.p2=p2;
		    this.q1=q1;
		    this.q2=q2;
		    this.n_symbols=n_symbols;
		    this.post1=post1;
		    this.post_len1=post_len1;
		    this.post2=post2;
		    this.post_len2=post_len2;
		    this.jump=jump;
		    this.jump_len=jump_len;
		    this.acc_jump=acc_jump;
		    this.acc_jump_len=acc_jump_len;
		    this.W=W;
		    this.la=la;
		}
	
		protected Integer compute(){
		    if ((p2-p1 <= threshold_forkjoin_la(n_states)) || (q2-q1 <= threshold_forkjoin_la(n_states))) {
		    	return single_BLAFair_refine_W(p1,p2,q1,q2,n_symbols,post1,post_len1,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,la);
		    }
		    else{
		    	jumping_par_refine_W t1 = new jumping_par_refine_W(p1,p1+(p2-p1)/2,q1,q1+(q2-q1)/2,n_symbols,post1,post_len1,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,la);
		    	jumping_par_refine_W t2 = new jumping_par_refine_W(p1,p1+(p2-p1)/2,q1+(q2-q1)/2,q2,n_symbols,post1,post_len1,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,la);
		    	jumping_par_refine_W t3 = new jumping_par_refine_W(p1+(p2-p1)/2,p2,q1,q1+(q2-q1)/2,n_symbols,post1,post_len1,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,la);
		    	jumping_par_refine_W t4 = new jumping_par_refine_W(p1+(p2-p1)/2,p2,q1+(q2-q1)/2,q2,n_symbols,post1,post_len1,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,la);
				t2.fork();
				t3.fork();
				t4.fork();
				int r1=t1.compute();
				int r2=t2.join();
				int r3=t3.join();
				int r4=t4.join();
				return(r1+r2+r3+r4);
		    }
		}
    }

    private int single_BLAFair_refine_W(int p1, int p2, int q1, int q2, int n_symbols, int[][][] post1, int[][] post_len1, int[][][] post2, int[][] post_len2, int[][] jump, int[] jump_len, int[][] acc_jump, int[] acc_jump_len, boolean[][] W, int la)
    {
    	int[] attack = new int[2*la+1];
    	boolean changed=false;
    	for(int p=p1; p<p2; p++)	
    	    for(int q=q1; q<q2; q++){
    		if(W[p][q]) continue; // true remains true;
    		attack[0]=p;
    		if(JumpingBLAFair_attack(q,n_symbols,post1,post_len1,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,la,attack,0)) { W[p][q]=true; changed=true; }
    	    }
	    if(changed) return(1); else return(0);
    }
    
    
private boolean JumpingBLAFair_refine_W(int n1, int n2, int n_symbols, int[][][] post1, int[][] post_len1, int[][][] post2, int[][] post_len2, int[][] jump, int[] jump_len, int[][] acc_jump, int[] acc_jump_len, boolean[][] W, int la)
    {
	int[] attack = new int[2*la+1];
	boolean changed=false;
	for(int p=0; p<n1; p++)	
	    for(int q=0; q<n2; q++){
			if(W[p][q]) continue; // true remains true;
			attack[0]=p;
			if(JumpingBLAFair_attack(q,n_symbols,post1,post_len1,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,la,attack,0)) { W[p][q]=true; changed=true; }
	    }
	return changed;
    }


private boolean JumpingBLAFair_attack(int q, int n_symbols, int[][][] post1, int[][] post_len1, int[][][] post2, int[][] post_len2, int[][] jump, int[] jump_len, int[][] acc_jump, int[] acc_jump_len, boolean[][] W, int la, int[] attack, int depth)
{
    if (depth==2*la) return (!JumpingBLAFair_defense(q,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,la,attack,0)); 
    
    if (depth > 0){
	if(JumpingBLAFair_defense(q,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,(depth/2),attack,0)) return false;
    }

    // if deadlock for attacker then try the attack so far
    int successors=0;
    for(int s=0;s<n_symbols;s++) successors += post_len1[s][attack[depth]];
    if(successors==0) {
	if(depth==0) return false;
	else return(!JumpingBLAFair_defense(q,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,(depth/2),attack,0));
    }
    
    for(int s=0;s<n_symbols;s++) 
	if(post_len1[s][attack[depth]]>0){
	    for(int r=0; r<post_len1[s][attack[depth]]; r++){
		attack[depth+1]=s;
		attack[depth+2]=post1[s][attack[depth]][r];
		if(JumpingBLAFair_attack(q,n_symbols,post1,post_len1,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,la,attack,depth+2)) return(true);
	    }
	}
    return false;
}

private boolean JumpingBLAFair_defense(int q, int[][][] post2, int[][] post_len2, int[][] jump, int[] jump_len, int[][] acc_jump, int[] acc_jump_len, boolean[][] W, int la, int[] attack, int depth)
{
    if((depth >0) && !W[attack[depth]][q]) return true; 
    if(depth==2*la) return(!W[attack[depth]][q]);
    int s=attack[depth+1];
    for(int j=0; j<jump_len[q]; j++)
	if(post_len2[s][jump[q][j]]>0){
	    for(int r=0; r<post_len2[s][jump[q][j]]; r++)
		if(JumpingBLAFair_defense(post2[s][jump[q][j]][r],post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,la,attack,depth+2)) return true;
	}
    for(int j=0; j<acc_jump_len[q]; j++)
	if(post_len2[s][acc_jump[q][j]]>0){
	    for(int r=0; r<post_len2[s][acc_jump[q][j]]; r++)
		if(JumpingBLAFair_defense(post2[s][acc_jump[q][j]][r],post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,la,attack,depth+2)) return true;
	}
    return false;
}



private void JumpingBLAFair_getavoid(boolean[] isFinal1, boolean[] isFinal2, int n1, int n2, int n_symbols, int[][][] post1, int[][] post_len1, int[][][] post2, int[][] post_len2, int[][] jump, int[] jump_len, int[][] acc_jump, int[] acc_jump_len, boolean[][] W, boolean[][] X, int la){

boolean[][] Y = new boolean[n1][n2];
int[] attack = new int[2*la+1];

// Start with X (i.e., avoid) as true and refine downward
for(int p=0; p<n1; p++)
    for(int q=0; q<n2; q++)
	X[p][q]=true;
		
boolean changed_x=true;
while(changed_x){
    changed_x=false;
    // Y is at least W and refined upward
    for(int p=0; p<n1; p++)
	for(int q=0; q<n2; q++) Y[p][q]=W[p][q];
    boolean changed_y=true;
    while(changed_y){
	changed_y=false;
	for(int p=0; p<n1; p++)
	    for(int q=0; q<n2; q++){
		if(Y[p][q]) continue; // If Y true then stay true
		if(isFinal2[q]) continue; // In getavoid duplicator can't accept, except in W (the part of Y in W is already true; see above)
		attack[0]=p;
		if(JumpingBLAFair_getavoid_attack(q,isFinal1,isFinal2,n_symbols,post1,post_len1,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,X,Y,la,attack,0))  { Y[p][q]=true; changed_y=true; }
	    }
    }
    // X becomes Y, i.e., remove true elements of X that are not true in Y
    for(int p=0; p<n1; p++)
	for(int q=0; q<n2; q++){
	    if(X[p][q] && !Y[p][q]) { X[p][q]=false; changed_x=true; }
	}
}
}


private boolean JumpingBLAFair_getavoid_attack(int q, boolean[] isFinal1, boolean[] isFinal2, int n_symbols, int[][][] post1, int[][] post_len1, int[][][] post2, int[][] post_len2, int[][] jump, int[] jump_len, int[][] acc_jump, int[] acc_jump_len, boolean[][] W, boolean[][] X, boolean[][] Y, int la, int[] attack, int depth)
{
    if (depth==2*la) return (!JumpingBLAFair_getavoid_defense(q,isFinal1,isFinal2,n_symbols,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,X,Y,la,attack,0,false)); 
    
    if (depth > 0){
	if(JumpingBLAFair_getavoid_defense(q,isFinal1,isFinal2,n_symbols,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,X,Y,(depth/2),attack,0,false)) return false;
    }

    // if deadlock for attacker then try the attack so far
    int successors=0;
    for(int s=0;s<n_symbols;s++) successors += post_len1[s][attack[depth]];
    if(successors==0) {
	if(depth==0) return false;
	else return(!JumpingBLAFair_getavoid_defense(q,isFinal1,isFinal2,n_symbols,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,X,Y,(depth/2),attack,0,false));
    }
    
    for(int s=0;s<n_symbols;s++) 
	if(post_len1[s][attack[depth]]>0){
	    for(int r=0; r<post_len1[s][attack[depth]]; r++){
		attack[depth+1]=s;
		attack[depth+2]=post1[s][attack[depth]][r];
		if(JumpingBLAFair_getavoid_attack(q,isFinal1,isFinal2,n_symbols,post1,post_len1,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,X,Y,la,attack,depth+2)) return(true);
	    }
	}
    return false;
}


private boolean JumpingBLAFair_getavoid_defense(int q, boolean[] isFinal1, boolean[] isFinal2, int n_symbols, int[][][] post2, int[][] post_len2, int[][] jump, int[] jump_len, int[][] acc_jump, int[] acc_jump_len, boolean[][] W, boolean[][] X, boolean[][] Y, int la, int[] attack, int depth, boolean acc)
{
    if((isFinal2[q]) && !W[attack[depth]][q]) return true;

    if(isFinal1[attack[depth]]) acc=true;
    if(depth>0){
	boolean result=true;
	if(Y[attack[depth]][q]) result=false; 
	if(acc && X[attack[depth]][q]) result=false;
	if(result) return true;
	if(depth==2*la) return result;
    }

    int s=attack[depth+1];

    for(int j=0; j<acc_jump_len[q]; j++)
	if(post_len2[s][acc_jump[q][j]]>0){
	    for(int r=0; r<post_len2[s][acc_jump[q][j]]; r++){
		if(!W[attack[depth+2]][post2[s][acc_jump[q][j]][r]]) return true;
		// Is the next line needed? W is winning for spoiler anyway.
		if(JumpingBLAFair_getavoid_defense(post2[s][acc_jump[q][j]][r],isFinal1,isFinal2,n_symbols,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,X,Y,la,attack,depth+2,acc)) return true;
	    }
	}

    for(int j=0; j<jump_len[q]; j++)
	if(post_len2[s][jump[q][j]]>0){
	    for(int r=0; r<post_len2[s][jump[q][j]]; r++)
		if(JumpingBLAFair_getavoid_defense(post2[s][jump[q][j]][r],isFinal1,isFinal2,n_symbols,post2,post_len2,jump,jump_len,acc_jump,acc_jump_len,W,X,Y,la,attack,depth+2,acc)) return true;
	}

    return false;
}

private int get_jump(int[][] jump, int[] jump_len, int[][] acc_jump, int[] acc_jump_len, boolean[][] W, boolean[] isFinal, int n_states){
    int result=0; // How many elements in W are true

    for(int p=0; p<n_states; p++){
	jump_len[p]=0;
	acc_jump_len[p]=0;
	for(int q=0; q<n_states; q++)
	    if(W[p][q] && isFinal[q]){
		acc_jump[p][acc_jump_len[p]++] = q;
		result++;
	    }
	int accepts=acc_jump_len[p];
	for(int q=0; q<n_states; q++)
	    if(W[p][q] && !isFinal[q]){
		result++;
		if(jump_bigger(q,acc_jump[p],accepts,W)) acc_jump[p][acc_jump_len[p]++] = q;
		else jump[p][jump_len[p]++] = q;
	    }
    }
    return result;
}

private boolean jump_bigger(int q, int[] seq, int len, boolean[][] W){

    for(int p=0; p<len; p++)
	if(W[seq[p]][q]) return true;

    return false;
}

	/**
 * Compute the transitive closure of bounded lookahead direct backward simulation on/between two Buchi automata
 * This is an underapproximation of direct backward trace inclusion (respecting initial and final states).
 * @param omega1, omega2: two Buchi automata. la: lookahead, must be >= 1
 *
 * @return A relation that underapproximates direct backward trace inclusion.
 */

public Set<Pair<FAState,FAState>> BLABSimRelNBW(FiniteAutomaton omega1,FiniteAutomaton omega2, int la) 
{
	ArrayList<FAState> all_states=new ArrayList<FAState>();
	HashSet<String> alphabet=new HashSet<String>();

       	all_states.addAll(omega1.states);
	alphabet.addAll(omega1.alphabet);

	if(omega2!=null){
		all_states.addAll(omega2.states);
		alphabet.addAll(omega2.alphabet);
	}

	int n_states = all_states.size();
	int n_symbols = alphabet.size();

	// Reverse the internal order of states. finite_removeDead + toArray puts states close to initstate last,
	// which is bad for bw sim (less in-situ effect). So we reverse the order here.
	FAState[] rev_states = all_states.toArray(new FAState[0]);
	FAState[] states = new FAState[n_states];
	for(int i=0; i<n_states; i++) states[n_states-i-1]=rev_states[i];
	
	boolean[][] W = new boolean[n_states][n_states];

	{
	ArrayList<String> symbols=new ArrayList<String>(alphabet);

	boolean[] isFinal = new boolean[n_states];
	boolean[] isInit = new boolean[n_states];
	for(int i=0;i<n_states;i++){			
		isFinal[i] = states[i].getowner().F.contains(states[i]);
		isInit[i] =states[i].getowner().getInitialState().compareTo(states[i])==0;
	}

	// Actually post is initialized as pre, because all is reversed in bw sim.
	int[][][] post = new int[n_symbols][n_states][];
	int[][] post_len = new int[n_symbols][n_states];
	
	// System.out.println("Construct post");
	// Reverse mapping of states to their index numbers
	// System.out.println("Construct reverse mapping");
	TreeMap<FAState, Integer> rev_map = new TreeMap<FAState, Integer>();
	for(int i=0;i<n_states;i++) rev_map.put(states[i], i);
	for(int s=0;s<n_symbols;s++)
	{
		String a = symbols.get(s);
		for(int p=0; p<n_states; p++)
		    {
			post_len[s][p]=0;
			Set<FAState> next = states[p].getPre(a); 
			if (next != null){
			    post[s][p] = new int[states[p].getPre(a).size()];
			    /*
			    for(int q=0; q<n_states; q++)
				{
				    if(next.contains(states[q]))
					{
					post[s][p][post_len[s][p]++] = q;
					}
				}
			    */
			    Iterator<FAState> state_it = next.iterator();
			    while (state_it.hasNext()) {
				FAState state = state_it.next();
				post[s][p][post_len[s][p]++] = rev_map.get(state);
			    }
		
			}
		    }
	}
	
	// Initialize result. This will shrink by least fixpoint iteration.
	for(int p=0; p<n_states; p++)
	    for(int q=0; q<n_states; q++){
		if(isFinal[p] && !isFinal[q]) { W[p][q]=false; continue; }
		if(isInit[p] && !isInit[q]) { W[p][q]=false; continue; }
		W[p][q]=true;
		for(int s=0;s<n_symbols;s++)
		    if(post_len[s][p]>0 && post_len[s][q]==0) W[p][q]=false; // p can do action s, but q cannot
	    }


	// Extra Dijkstra removal
	// System.out.println("Computing Dijkstra");
	int initstate1 = rev_map.get(omega1.getInitialState());
	int initstate2=0; 
	if(omega2 != null) initstate2 = rev_map.get(omega2.getInitialState());

	// First compute forward ajdacency list of states, by any symbol
	int[][] adj = new int[n_states][];
	int[] adj_len = new int[n_states];

	for(int p=0; p<n_states; p++){
	    adj_len[p]=0;
	    Set<FAState> next = new TreeSet<FAState>();
	    for(int s=0;s<n_symbols;s++){
		String a = symbols.get(s);
		if(states[p].getNext(a) != null) next.addAll(states[p].getNext(a));
	    }
	    if (next != null){
		adj[p] = new int[next.size()];
		Iterator<FAState> state_it = next.iterator();
		while (state_it.hasNext()) {
		    FAState state = state_it.next();
		    adj[p][adj_len[p]++] = rev_map.get(state);
		}
	    }
	}
	// minimal distance from some initial state (from omega1 or omega2) +1.
	// distance zero mean undefined as yet.
	int[] distance = new int[n_states];

	ArrayList<Integer> todo = new ArrayList<Integer>();
	todo.add(initstate1);
	if(omega2 != null) todo.add(initstate2);
	int length=1;
	distance[initstate1]=length;
	if(omega2 != null) distance[initstate2]=length;
	while(!todo.isEmpty()){
	    ArrayList<Integer> todonext = new ArrayList<Integer>();
	    ++length;
	    Iterator<Integer> it = todo.iterator();
	    while(it.hasNext()){
		int state = it.next();
		for(int n=0; n<adj_len[state]; n++){
		    if(distance[adj[state][n]]==0){
			distance[adj[state][n]]=length;
			todonext.add(adj[state][n]);
		    }
		}
	    }
	    todo=todonext;
	}

	//--------------------------------------------------------------

	// System.out.println("BW sim: List of distance from init: ");
	// for(int i=0; i<n_states; i++) System.out.print(distance[i]+"  ");
	
	// int dijk_removed=0;
	for(int p=0; p<n_states; p++)
	    for(int q=0; q<n_states; q++){
		// p can go back to some initstate quicker than q can, so q cannot bw simulate p.
		if((distance[p]>0) && (distance[q]>0) && (distance[p]<distance[q])){
		       if(W[p][q]){
			   W[p][q] = false;
			   // ++dijk_removed;
		       }
		}
	    }
	// System.out.println("BWsim Dijkstra removed pairs: "+dijk_removed);

	
	BLAB_refine(isFinal,isInit,n_states,n_symbols,post,post_len,W,la);

	}
	// Compute transitive closure
	close_transitive(W,n_states);

	// Create final result as set of pairs of states
	Set<Pair<FAState,FAState>> FSim2 = new TreeSet<Pair<FAState,FAState>>(new StatePairComparator());
	for(int p=0; p<n_states; p++)	
		for(int q=0; q<n_states; q++)
			if(W[p][q]) FSim2.add(new Pair<FAState, FAState>(states[p],states[q]));
	return FSim2;
}

private int close_transitive(boolean[][] W, int size)
{
int result=0;
for(int r=0; r<size; r++)
  for(int p=0; p<size; p++)
      if((p != r) && W[p][r]){
	  for(int q=0; q<size; q++){
	      if(W[p][q]) continue; // true stays true
	      if(W[r][q]) { W[p][q]=true; ++result; }
	  }
      }
  return result;
}

private void BLAB_refine(boolean[] isFinal, boolean[] isInit, int n_states, int n_symbols, int[][][] post, int[][] post_len, boolean[][] W, int la)
{
	// Start new thread for removing pairs: one can do a sequence of symbols that the other can't 
	// Only up-to depth 13, since otherwise it uses too much memory.
	// stop[0] is used as a flag to tell the thread to stop earlier, if needed.
	boolean[] stop = new boolean[1];
	stop[0]=false;
	// Count the number of pairs that the preref thread has removed since the last sync.
	// Can only terminate when this is zero.
	int[] removed = new int[1];
	removed[0]=0;

	acc_PrerefThread preref = new acc_PrerefThread(n_states,n_symbols,post,post_len,W,isFinal,parallel_depth_pre_refine(la, n_symbols),stop,removed);
	preref.start();

	boolean changed=true;
	while(changed){
	    // System.out.println("BLAB: States: "+n_states+" Matrix: "+count_matrix(W, n_states));
	    changed=(forkJoinPool.invoke(new par_BLAB_refine(0,n_states,0,n_states,isFinal,isInit,n_states,n_symbols,post,post_len,W,la)) >0);
	    if(removed[0]>0) changed=true;
	    removed[0]=0;
	}

	stop[0]=true;
	try{
	    preref.join();
	}
	catch (InterruptedException e) {};
}



class par_BLAB_refine extends RecursiveTask<Integer> {
int p1,p2,q1,q2;
boolean[] isFinal;
boolean[] isInit;
int n_states;
int n_symbols;
int[][][] post;
int[][] post_len; 
boolean[][] W;
int la;

par_BLAB_refine(int p1, int p2, int q1, int q2, boolean[] isFinal, boolean[] isInit, int n_states, int n_symbols, int[][][] post, int[][] post_len, boolean[][] W, int la){
    this.p1=p1;
    this.p2=p2;
    this.q1=q1;
    this.q2=q2;
    this.isFinal=isFinal;
    this.isInit=isInit; 
    this.n_states=n_states;
    this.n_symbols=n_symbols;
    this.post=post;
    this.post_len=post_len;
    this.W=W;
    this.la=la;
}

protected Integer compute(){
    if ((p2-p1 <= threshold_forkjoin_la(n_states)) || (q2-q1 <= threshold_forkjoin_la(n_states))) {
	return single_BLAB_refine(p1,p2,q1,q2,isFinal,isInit,n_states,n_symbols,post,post_len,W,la);
    }
    else{
	par_BLAB_refine t1 = new par_BLAB_refine(p1,p1+(p2-p1)/2,q1,q1+(q2-q1)/2,isFinal,isInit,n_states,n_symbols,post,post_len,W,la);
	par_BLAB_refine t2 = new par_BLAB_refine(p1,p1+(p2-p1)/2,q1+(q2-q1)/2,q2,isFinal,isInit,n_states,n_symbols,post,post_len,W,la);
	par_BLAB_refine t3 = new par_BLAB_refine(p1+(p2-p1)/2,p2,q1,q1+(q2-q1)/2,isFinal,isInit,n_states,n_symbols,post,post_len,W,la);
	par_BLAB_refine t4 = new par_BLAB_refine(p1+(p2-p1)/2,p2,q1+(q2-q1)/2,q2,isFinal,isInit,n_states,n_symbols,post,post_len,W,la);
	t2.fork();
	t3.fork();
	t4.fork();
	int r1=t1.compute();
	int r2=t2.join();
	int r3=t3.join();
	int r4=t4.join();
	return(r1+r2+r3+r4);
    }
}

}


private int single_BLAB_refine(int p1, int p2, int q1, int q2, boolean[] isFinal, boolean[] isInit, int n_states, int n_symbols, int[][][] post, int[][] post_len, boolean[][] W, int la)
{
int[] attack = new int[2*la+1];
int[] poss = new int[n_states];
int poss_len=0;
boolean changed=false;
for(int p=p1; p<p2; p++)	
    for(int q=q1; q<q2; q++){
	if(!W[p][q]) continue; // false remains false;
	attack[0]=p;
	poss[0]=q;  // we assume (!isFinal[p] || isFinal[q])) by prev. ref. of W
	poss_len=1;
	//defender starts at q
	if(i_BLAB_attack(isFinal,isInit,n_states,n_symbols,post,post_len,W,la,attack,0,poss,poss_len)) { W[p][q]=false; changed=true; }
    }
if(changed) return(1); else return(0);
}


private boolean i_BLAB_attack(boolean[] isFinal, boolean[] isInit, int n_states, int n_symbols, int[][][] post, int[][] post_len, boolean[][] W, int la, int[] attack, int depth, int[] poss, int poss_len)
{
int[] newposs = new int[n_states];
int[] newposs_len = new int[1];

// interate through all one-step extensions of the attack

boolean hint=false;
for(int s=0;s<n_symbols;s++) 
if(post_len[s][attack[depth]]>0){

    // First iterate through successors that are initial; these should be rare. No caching is done here
    for(int r=0; r<post_len[s][attack[depth]]; r++) if(isInit[post[s][attack[depth]][r]]) {
	attack[depth+1]=s;
	attack[depth+2]=post[s][attack[depth]][r];
	int d = i_BLAB_defense_init(isFinal, isInit, n_states, n_symbols, post, post_len, W, attack, depth+2, poss, poss_len, newposs, newposs_len);
	if(d==0) return true; // strong def. fail; successful attack 
	if(d==2) continue; // def. success; this attack failed, but others might still succeed
	// here d==1; weak def. fail, but possibilities computed
	if(depth+2 == 2*la) return true; // tested attack above was of maxdepth; no extension; weak def. fail means fail.
	// Check if last attack state is deadlocked
	int successors=0;
	for(int t=0;t<n_symbols;t++) successors += post_len[t][attack[depth+2]];
	if(successors==0) return true; // No extension of attack possible; weak def. fail means fail.
	
	if(i_BLAB_attack(isFinal,isInit,n_states,n_symbols,post,post_len,W,la,attack,depth+2,newposs,newposs_len[0])) return(true);
    }

    // Now we consider only non-initial successors
    // First iterate through accepting successors; search heuristic
    hint=false;
    for(int r=0; r<post_len[s][attack[depth]]; r++) if(!isInit[post[s][attack[depth]][r]] && isFinal[post[s][attack[depth]][r]]) {
	attack[depth+1]=s;
	attack[depth+2]=post[s][attack[depth]][r];
	int d = i_BLAB_defense_acc(isFinal, n_states, n_symbols, post, post_len, W, attack, depth+2, poss, poss_len, newposs, newposs_len, hint);
	if(d==0) return true; // strong def. fail; successful attack 
	if(d==2) continue; // def. success; this attack failed, but others might still succeed
	// here d==1; weak def. fail, but possibilities computed
	if(depth+2 == 2*la) return true; // tested attack above was of maxdepth; no extension; weak def. fail means fail.
	// Check if last attack state is deadlocked
	int successors=0;
	for(int t=0;t<n_symbols;t++) successors += post_len[t][attack[depth+2]];
	if(successors==0) return true; // No extension of attack possible; weak def. fail means fail.
	
	hint=true;  // newposs is computed
	if(i_BLAB_attack(isFinal,isInit,n_states,n_symbols,post,post_len,W,la,attack,depth+2,newposs,newposs_len[0])) return(true);
    }

    // Now iterate through non-accepting (and non-initial) successors
    hint=false;
    for(int r=0; r<post_len[s][attack[depth]]; r++) if(!isInit[post[s][attack[depth]][r]] && !isFinal[post[s][attack[depth]][r]]) {
	attack[depth+1]=s;
	attack[depth+2]=post[s][attack[depth]][r];
	int d = i_BLAB_defense_nonacc(isFinal, n_states, n_symbols, post, post_len, W, attack, depth+2, poss, poss_len, newposs, newposs_len, hint);
	if(d==0) return true; // strong def. fail; successful attack 
	if(d==2) continue; // def. success; this attack failed, but others might still succeed
	// here d==1; weak def. fail, but possibilities computed
	if(depth+2 == 2*la) return true; // tested attack above was of maxdepth; no extension; weak def. fail means fail.
	// Check if last attack state is deadlocked
	int successors=0;
	for(int t=0;t<n_symbols;t++) successors += post_len[t][attack[depth+2]];
	if(successors==0) return true; // No extension of attack possible; weak def. fail means fail.
	
	hint=true;  // newposs is computed
	if(i_BLAB_attack(isFinal,isInit,n_states,n_symbols,post,post_len,W,la,attack,depth+2,newposs,newposs_len[0])) return(true);
    }

}

return false;
}


private int i_BLAB_defense_init(boolean[] isFinal, boolean[] isInit, int n_states, int n_symbols, int[][][] post, int[][] post_len, boolean[][] W, int[] attack, int depth, int [] poss, int poss_len, int[] newposs, int[] newposs_len)
{
boolean weak = false;
int s=attack[depth-1];

if(poss_len*poss_len <= 4*n_states){
newposs_len[0]=0;
for(int i=0; i<poss_len; i++){
    for(int r=0; r<post_len[s][poss[i]]; r++){
	if(!isInit[post[s][poss[i]][r]]) continue;  // def. needs to be initial here, since attack[depth] is
	if(isFinal[attack[depth]] && !isFinal[post[s][poss[i]][r]]) continue;  // must repect acceptance condition
	if(W[attack[depth]][post[s][poss[i]][r]]) return(2); // successful defense
	arrad(newposs,newposs_len,post[s][poss[i]][r]); weak=true; // only weak fail here
    }
}
} else{
boolean[] xposs = new boolean[n_states]; // all initially false
newposs_len[0]=0;
for(int i=0; i<poss_len; i++){
    for(int r=0; r<post_len[s][poss[i]]; r++){
	if(!isInit[post[s][poss[i]][r]]) continue;  // def. needs to be initial here, since attack[depth] is
	if(isFinal[attack[depth]] && !isFinal[post[s][poss[i]][r]]) continue;  // must repect acceptance condition
	if(W[attack[depth]][post[s][poss[i]][r]]) return(2); // successful defense
	xposs[post[s][poss[i]][r]]=true; weak=true; // only weak fail here
    }
}
	for(int i=0; i<n_states; i++) if(xposs[i]) newposs[newposs_len[0]++]=i;
}    
if(weak) return(1); else return(0);
}



private int i_BLAB_defense_acc(boolean[] isFinal, int n_states, int n_symbols, int[][][] post, int[][] post_len, boolean[][] W, int[] attack, int depth, int[] poss, int poss_len, int[] newposs, int[] newposs_len, boolean hint)
{
boolean weak = false;
int s=attack[depth-1];

if(hint){
weak = (newposs_len[0]>0);
for(int i=0; i<newposs_len[0]; i++){
	if(W[attack[depth]][newposs[i]]) return(2);
    }
} else{
if(poss_len*poss_len <= 4*n_states){
    newposs_len[0]=0;
    for(int i=0; i<poss_len; i++){
	for(int r=0; r<post_len[s][poss[i]]; r++){
	    if(!isFinal[post[s][poss[i]][r]]) continue;
	    if(W[attack[depth]][post[s][poss[i]][r]]) return(2); // successful defense
	    arrad(newposs,newposs_len,post[s][poss[i]][r]); weak=true; // only weak fail here
	}
    }
} else{
    boolean[] xposs = new boolean[n_states]; // all initially false
    newposs_len[0]=0;
    for(int i=0; i<poss_len; i++){
	for(int r=0; r<post_len[s][poss[i]]; r++){
	    if(!isFinal[post[s][poss[i]][r]]) continue;
	    if(W[attack[depth]][post[s][poss[i]][r]]) return(2); // successful defense
	    xposs[post[s][poss[i]][r]]=true; weak=true; // only weak fail here
	}
    }
    for(int i=0; i<n_states; i++) if(xposs[i]) newposs[newposs_len[0]++]=i;
}
}
if(weak) return(1); else return(0);
}



private int i_BLAB_defense_nonacc(boolean[] isFinal, int n_states, int n_symbols, int[][][] post, int[][] post_len, boolean[][] W, int[] attack, int depth, int[] poss, int poss_len, int[] newposs, int[] newposs_len, boolean hint)
{
boolean weak = false;
int s=attack[depth-1];

if(hint){
weak = (newposs_len[0]>0);
for(int i=0; i<newposs_len[0]; i++){
	if(W[attack[depth]][newposs[i]]) return(2);
    }
} else{
if(poss_len*poss_len <= 4*n_states){
    newposs_len[0]=0;
    for(int i=0; i<poss_len; i++){
	for(int r=0; r<post_len[s][poss[i]]; r++){
	    if(W[attack[depth]][post[s][poss[i]][r]]) return(2); // successful defense
	    arrad(newposs,newposs_len,post[s][poss[i]][r]); weak=true; // only weak fail here
	}
    }
} else{
    boolean[] xposs = new boolean[n_states]; // all initially false
    newposs_len[0]=0;
    for(int i=0; i<poss_len; i++){
	for(int r=0; r<post_len[s][poss[i]]; r++){
	    if(W[attack[depth]][post[s][poss[i]][r]]) return(2); // successful defense
	    xposs[post[s][poss[i]][r]]=true; weak=true; // only weak fail here
	}
    }
    for(int i=0; i<n_states; i++) if(xposs[i]) newposs[newposs_len[0]++]=i;
}
}
if(weak) return(1); else return(0);
}

private int parallel_depth_pre_refine(int la, int n_symbols)
{
    int magic = 5000; // about 2^13 for depth 13

    if(n_symbols <= 0) return 1;
    else if(n_symbols==1) return Math.min(la, 13);
    else if(n_symbols >= magic) return 1;
    else return (int)(Math.log((double)magic)/Math.log((double)n_symbols));
}

private void arrad(int[] l, int[] len, int x){
    for(int i=0; i<len[0]; i++) if(l[i]==x) return;
    l[len[0]]=x;
    ++len[0];
    return;
}

}
