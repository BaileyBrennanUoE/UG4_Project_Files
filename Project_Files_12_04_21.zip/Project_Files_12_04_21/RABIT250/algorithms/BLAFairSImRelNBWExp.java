package algorithms;

import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

import automata.FAState;
import automata.FiniteAutomaton;
import comparator.StatePairComparator;
import datastructure.HashSet;
import datastructure.Pair;

public class BLAFairSImRelNBWExp{
	
	private int num_proc;
    private ForkJoinPool forkJoinPool;
	
	private int threshold_forkjoin_la(int n_states){
        return Math.max(10,n_states/64);
    }
	
	BLAFairSImRelNBWExp(int cores){
		this.num_proc = cores;
	    this.forkJoinPool = new ForkJoinPool(num_proc);
	}
    
  //-----------------------------------------------------------------------------------------------------------------------
    /**
     * Compute BLA fair forward simulation on/between two Buchi automata
     * @param omega1, omega2: two Buchi automata
     * @param la: integer >=1, the lookahead
     *
     * @return the transitive closure of the simulation relation
     * Advice: Use this only for benchmark tests. Otherwise use jumping BLA fair sim.
     */

    public Set<Pair<FAState,FAState>> BLAFairSimRelNBW(FiniteAutomaton omega1, FiniteAutomaton omega2, int la) 
         {
        ArrayList<FAState> all_states=new ArrayList<FAState>();
        HashSet<String> alphabet=new HashSet<String>();

        all_states.addAll(omega1.states);
        alphabet.addAll(omega1.alphabet);

        if(omega2!=null) {
            all_states.addAll(omega2.states);
            alphabet.addAll(omega2.alphabet);
        }

        int n_states = all_states.size();
        int n_symbols = alphabet.size();

        boolean[][] W = new boolean[n_states][n_states];

        FAState[] states = all_states.toArray(new FAState[0]);

        ArrayList<String> symbols=new ArrayList<String>(alphabet);

        boolean[] isFinal = new boolean[n_states];
        for(int i=0;i<n_states;i++){            
            isFinal[i] = states[i].getowner().F.contains(states[i]);
        }
        
        int[][][] post = new int[n_symbols][n_states][];
        int[][] post_len = new int[n_symbols][n_states];
        
        for(int s=0;s<n_symbols;s++)
        {
            String a = symbols.get(s);
            for(int p=0; p<n_states; p++)
                {
                //System.out.println("Delayed sim: Getting post: Iterating p: "+p+" of "+n_states+" s is "+s+" of "+n_symbols);
                post_len[s][p]=0;
                Set<FAState> next = states[p].getNext(a); 
                if (next != null){
                    post[s][p] = new int[states[p].getNext(a).size()];
                    for(int q=0; q<n_states; q++)
                    {
                        if(next.contains(states[q]))
                        {
                        post[s][p][post_len[s][p]++] = q;
                        }
                    }
                }
                }
        }
        
        // Initialize result W (winning for spolier). This will grow by least fixpoint iteration.
        for(int p=0; p<n_states; p++)
            for(int q=0; q<n_states; q++){
            W[p][q]=false;
            for(int s=0;s<n_symbols;s++)
                if(post_len[s][p]>0 && post_len[s][q]==0) W[p][q]=true; // p can do action s, but q cannot
            }

        boolean[][] avoid = new boolean[n_states][n_states];
                    
        boolean changed=true;
        while(changed){
            // System.out.println("Computing BLAFair getavoid.");
            changed=false;
            //BLAFair_getavoid(isFinal,n_states,n_symbols,post,post_len,W,avoid,la);
            //long start = System.currentTimeMillis();
            get_avoid(isFinal,n_states,n_symbols,post,post_len,W,avoid,la);
            //System.out.println("\t\t Exp Get Avoid time:"+(System.currentTimeMillis()-start));
            // Copy avoid to W
            for(int p=0; p<n_states; p++)
            	for(int q=0; q<n_states; q++)
            		if(avoid[p][q] && !W[p][q]) { 
            			W[p][q]=true; 
            			changed=true;
            		}
            // Add pairs where spoiler can force the game into W
            // System.out.println("Refining BLAFair.");
            //start = System.currentTimeMillis();
            if(BLAFairPar_refine_W(isFinal,n_states,n_symbols,post,post_len,W,la)) changed=true;
            //System.out.println("\t\t Exp Refine time:"+(System.currentTimeMillis()-start));
        }

        // Invert to get duplicator winning states
        for(int p=0; p<n_states; p++)   
            for(int q=0; q<n_states; q++) W[p][q] = !W[p][q];

        // Compute transitive closure
        close_transitive(W,n_states);
        // Create final result as set of pairs of states
        Set<Pair<FAState,FAState>> FSim2 = new TreeSet<Pair<FAState,FAState>>(new StatePairComparator());
        for(int p=0; p<n_states; p++)   
            for(int q=0; q<n_states; q++)
                if(W[p][q]) FSim2.add(new Pair<FAState, FAState>(states[p],states[q]));
        return FSim2;
    }

    private boolean BLAFairPar_refine_W(boolean[] isFinal, int n_states, int n_symbols, int[][][] post, int[][] post_len, boolean[][] W, int la)
    {
    	boolean changed = true;//=(forkJoinPool.invoke(new par_refine_W(0,n_states,0,n_states,isFinal,n_states,n_symbols,post,post_len,W, la))>0);
    	while(changed) {
    		changed = false;
    		changed=(forkJoinPool.invoke(new par_BLAFair_refine_W(0,n_states,0,n_states,isFinal,n_states,n_symbols,post,post_len,W, la))>0);
    	}
    	return changed;
    }
	
    class par_BLAFair_refine_W extends RecursiveTask<Integer> {
	int p1,p2,q1,q2;
	boolean[][] avoid;
	boolean[] isFinal;
	int n_states;
	int n_symbols;
	int[][][] post;
	int[][] post_len; 
	boolean[][] W;
	int la;
	
	par_BLAFair_refine_W(int p1, int p2, int q1, int q2, boolean[] isFinal, int n_states, int n_symbols, int[][][] post, int[][] post_len, boolean[][] W, int la){
	    this.p1=p1;
	    this.p2=p2;
	    this.q1=q1;
	    this.q2=q2;
	    this.isFinal=isFinal;
	    this.n_states=n_states;
	    this.n_symbols=n_symbols;
	    this.post=post;
	    this.post_len=post_len;
	    this.W=W;
	    this.la=la;
	}

	protected Integer compute(){
	    if ((p2-p1 <= threshold_forkjoin_la(n_states)) || (q2-q1 <= threshold_forkjoin_la(n_states))) {
	    	return single_BLAFair_refine_W(p1,p2,q1,q2,n_states,n_symbols,post,post_len,W,la);
	    }
	    else{
	    	par_BLAFair_refine_W t1 = new par_BLAFair_refine_W(p1,p1+(p2-p1)/2,q1,q1+(q2-q1)/2,isFinal,n_states,n_symbols,post,post_len,W,la);
	    	par_BLAFair_refine_W t2 = new par_BLAFair_refine_W(p1,p1+(p2-p1)/2,q1+(q2-q1)/2,q2,isFinal,n_states,n_symbols,post,post_len,W,la);
	    	par_BLAFair_refine_W t3 = new par_BLAFair_refine_W(p1+(p2-p1)/2,p2,q1,q1+(q2-q1)/2,isFinal,n_states,n_symbols,post,post_len,W,la);
	    	par_BLAFair_refine_W t4 = new par_BLAFair_refine_W(p1+(p2-p1)/2,p2,q1+(q2-q1)/2,q2,isFinal,n_states,n_symbols,post,post_len,W,la);
			t2.fork();
			t3.fork();
			t4.fork();
			int r1=t1.compute();
			int r2=t2.join();
			int r3=t3.join();
			int r4=t4.join();
			return(r1+r2+r3+r4);
	    }
	}
    }

    private int single_BLAFair_refine_W(int p1, int p2, int q1, int q2, int n_states, int n_symbols, int[][][] post, int[][] post_len, boolean[][] W, int la)
    {
	    int[] attack = new int[2*la+1];
	    boolean changed=false;
	    for(int p=p1; p<p2; p++)  
	        for(int q=q1; q<q2; q++){
	        	if(W[p][q]) continue; // true remains true;
	        	attack[0]=p;
	        	if(BLAFair_attack(q,n_symbols,post,post_len,W,la,attack,0)) { W[p][q]=true; changed=true; }
	        }
	    if(changed) return(1); else return(0);
    }


    private boolean BLAFair_attack(int q, int n_symbols, int[][][] post, int[][] post_len, boolean[][] W, int la, int[] attack, int depth)
    {
        if (depth==2*la) return (!BLAFair_defense(q,post,post_len,W,la,attack,0)); 
        
        if (depth > 0){
        if(BLAFair_defense(q,post,post_len,W,(depth/2),attack,0)) return false;
        }
    
        // if deadlock for attacker then try the attack so far
        int successors=0;
        for(int s=0;s<n_symbols;s++) successors += post_len[s][attack[depth]];
	        if(successors==0) {
	        	if(depth==0) return false;
	        else return(!BLAFair_defense(q,post,post_len,W,(depth/2),attack,0));
	        }
	        
        for(int s=0;s<n_symbols;s++) 
	        if(post_len[s][attack[depth]]>0){
	            for(int r=0; r<post_len[s][attack[depth]]; r++){
		            attack[depth+1]=s;
		            attack[depth+2]=post[s][attack[depth]][r];
		            if(BLAFair_attack(q,n_symbols,post,post_len,W,la,attack,depth+2)) return(true);
	            }
	        }
        return false;
    }

    private boolean BLAFair_defense(int q, int[][][] post, int[][] post_len, boolean[][] W, int la, int[] attack, int depth)
    {
        if((depth >0) && !W[attack[depth]][q]) return true; 
        if(depth==2*la) return(!W[attack[depth]][q]);
        int s=attack[depth+1];
        for(int j=0; j<post_len[s][q]; j++)
        	if(BLAFair_defense(post[s][q][j],post,post_len,W,la,attack,depth+2))
        		return true;
        return false;
    }


    class par_get_avoid extends RecursiveTask<Integer> {
		int p1,p2,q1,q2;
		boolean[][] avoid;
		boolean[] isFinal;
		int n_states;
		int n_symbols;
		int[][][] post;
		int[][] post_len; 
		boolean[][] W;
		boolean[][] X;
		int la;
		boolean[][] Y;
		int[] attack;
		
		par_get_avoid(int p1, int p2, int q1, int q2, boolean[] isFinal, int n_states, int n_symbols, int[][][] post, int[][] post_len, boolean[][] W, boolean[][] X, int la){
		    this.p1=p1;
		    this.p2=p2;
		    this.q1=q1;
		    this.q2=q2;
		    this.isFinal=isFinal;
		    this.n_states=n_states;
		    this.n_symbols=n_symbols;
		    this.post=post;
		    this.post_len=post_len;
		    this.W=W;
		    this.X=X;
		    this.la=la;
		}
	
		protected Integer compute(){
		    if ((p2-p1 <= threshold_forkjoin_la(n_states)) || (q2-q1 <= threshold_forkjoin_la(n_states))) {
		    	return single_get_avoid(p1,p2,q1,q2,isFinal,n_states,n_symbols,post,post_len,W,X,la);
		    }else{
				par_get_avoid t1 = new par_get_avoid(p1,p1+(p2-p1)/2,q1,q1+(q2-q1)/2,isFinal,n_states,n_symbols,post,post_len,W,X,la);
				par_get_avoid t2 = new par_get_avoid(p1,p1+(p2-p1)/2,q1+(q2-q1)/2,q2,isFinal,n_states,n_symbols,post,post_len,W,X,la);
				par_get_avoid t3 = new par_get_avoid(p1+(p2-p1)/2,p2,q1,q1+(q2-q1)/2,isFinal,n_states,n_symbols,post,post_len,W,X,la);
				par_get_avoid t4 = new par_get_avoid(p1+(p2-p1)/2,p2,q1+(q2-q1)/2,q2,isFinal,n_states,n_symbols,post,post_len,W,X,la);
				t2.fork();
				t3.fork();
				t4.fork();
				int r1=t1.compute();
				int r2=t2.join();
				int r3=t3.join();
				int r4=t4.join();
				return(r1+r2+r3+r4);
		    }
		}

    }

    private void get_avoid(boolean[] isFinal, int n, int n_symbols, int[][][] post, int[][] post_len, boolean[][] W, boolean[][] X, int la)
    {

    	boolean changed = true;
    	while(changed) {
    		changed=false;
    		changed=(forkJoinPool.invoke(new par_get_avoid(0,n,0,n,isFinal,n,n_symbols,post,post_len,W,X,la))>0);
    	}
    }

    private int single_get_avoid(int p1, int p2, int q1, int q2, boolean[] isFinal, int n_states, int n_symbols, int[][][] post, int[][] post_len, boolean[][] W, boolean[][] X, int la) {	
    	
    	
    	boolean[][] Y = new boolean[n_states][n_states];
	    int[] attack = new int[2*la+1];
	    
	    // Start with X (i.e., avoid) as true and refine downward
	    for(int p=p1; p<p2; p++)
	        for(int q=q1; q<q2; q++)
	        	X[p][q]=true;
	            
	    boolean changed_x=true;
	    while(changed_x){
	        changed_x=false;
	        // Y is at least W and refined upward
	        for(int p=p1; p<p2; p++)
	        	for(int q=q1; q<q2; q++)
	        		Y[p][q]=W[p][q];
	        boolean changed_y=true;
	        while(changed_y){
		        changed_y=false;
		        for(int p=p1; p<p2; p++)
		            for(int q=q1; q<q2; q++){
			            if(Y[p][q]) continue; // If Y true then stay true
			            if(isFinal[q]) continue; // In getavoid duplicator can't accept, except in W (the part of Y in W is already true; see above)
			            attack[0]=p;
			            if(BLAFair_getavoid_attack(q,isFinal,n_symbols,post,post_len,W,X,Y,la,attack,0))  { Y[p][q]=true; changed_y=true; }
		            }
	        }
	        // X becomes Y, i.e., remove true elements of X that are not true in Y
	        for(int p=p1; p<p2; p++)
	        	for(int q=q1; q<q2; q++){
	        		if(X[p][q] && !Y[p][q]) { X[p][q]=false; changed_x=true; }
	        	}
	    }

    	if(changed_x) return(1); else return(0);
    }
    
    private boolean BLAFair_getavoid_attack(int q, boolean[] isFinal, int n_symbols, int[][][] post, int[][] post_len, boolean[][] W, boolean[][] X, boolean[][] Y, int la, int[] attack, int depth)
    {
        if (depth==2*la) return (!BLAFair_getavoid_defense(q,isFinal,n_symbols,post,post_len,W,X,Y,la,attack,0,false)); 
        
        if (depth > 0){
        if(BLAFair_getavoid_defense(q,isFinal,n_symbols,post,post_len,W,X,Y,(depth/2),attack,0,false)) return false;
        }
    
        // if deadlock for attacker then try the attack so far
        int successors=0;
        for(int s=0;s<n_symbols;s++) successors += post_len[s][attack[depth]];
	        if(successors==0) {
	        if(depth==0) return false;
	        else return(!BLAFair_getavoid_defense(q,isFinal,n_symbols,post,post_len,W,X,Y,(depth/2),attack,0,false));
	        }
        
        for(int s=0;s<n_symbols;s++) 
	        if(post_len[s][attack[depth]]>0){
	            for(int r=0; r<post_len[s][attack[depth]]; r++){
	            attack[depth+1]=s;
	            attack[depth+2]=post[s][attack[depth]][r];
	            if(BLAFair_getavoid_attack(q,isFinal,n_symbols,post,post_len,W,X,Y,la,attack,depth+2)) return(true);
	            }
	        }
        return false;
    }


    private boolean BLAFair_getavoid_defense(int q, boolean[] isFinal, int n_symbols, int[][][] post, int[][] post_len, boolean[][] W, boolean[][] X, boolean[][] Y, int la, int[] attack, int depth, boolean acc)
    {
        if((isFinal[q]) && !W[attack[depth]][q]) return true;
    
        if(isFinal[attack[depth]]) acc=true;
        if(depth>0){
	        boolean result=true;
	        if(Y[attack[depth]][q]) result=false; 
	        if(acc && X[attack[depth]][q]) result=false;
	        if(result) return true;
	        if(depth==2*la) return result;
        }
    
        int s=attack[depth+1];
    
        for(int r=0; r<post_len[s][q]; r++){
        	if(BLAFair_getavoid_defense(post[s][q][r],isFinal,n_symbols,post,post_len,W,X,Y,la,attack,depth+2,acc)) return true;
        }
        return false;
    }
    
    private int close_transitive(boolean[][] W, int size)
    {
    int result=0;
    for(int r=0; r<size; r++)
      for(int p=0; p<size; p++)
          if((p != r) && W[p][r]){
          for(int q=0; q<size; q++){
              if(W[p][q]) continue; // true stays true
              if(W[r][q]) { W[p][q]=true; ++result; }
          }
          }
      return result;
    }
    
}
