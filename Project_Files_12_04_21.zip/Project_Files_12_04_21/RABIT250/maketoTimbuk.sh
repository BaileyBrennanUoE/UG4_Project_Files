jar cvfe toTimbuk.jar mainfiles.toTimbuk mainfiles/toTimbuk.class automata/*.class datastructure/*.class comparator/*.class algorithms/*.class
