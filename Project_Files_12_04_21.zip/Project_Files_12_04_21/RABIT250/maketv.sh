jar cvfe TV.jar mainfiles.TV mainfiles/TV.class automata/*.class datastructure/*.class comparator/*.class algorithms/*.class
