#https://stackoverflow.com/questions/7372592/python-how-can-i-execute-a-jar-file-through-a-python-script
from subprocess import *
from random import *

#replace variables below
#this is the path to TV.jar e.g. '/home/RABIT250/'
tvPath = '/home/RABIT250/'
#how many test files you want
n = 100
#size of the automata
size = '300'
#transition density
td = '1.7'
#acceptance density
ad = '0.5'
#number of symbols in the alphabet
alphabetSize = '2'

def jarWrapper(*args):
    process = Popen(['java', '-jar']+list(args), stdout=PIPE, stderr=PIPE)
    ret = []
    while process.poll() is None:
        line = process.stdout.readline()
        if line != '' and line.endswith('\n'):
            ret.append(line[:-1])
    stdout, stderr = process.communicate()
    ret += stdout.split('\n')
    if stderr != '':
        ret += stderr.split('\n')
    ret.remove('')
    return ret

def makeFiles():
    for x in range(0,n):
        args = [tvPath+'TV.jar', size, td, ad, alphabetSize, 'testFile'+str(x)]
        jarWrapper(*args)

makeFiles()
